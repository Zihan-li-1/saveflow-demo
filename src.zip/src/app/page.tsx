"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import "./scroll-fixes.css";
import {
  AlertTriangle, ArrowUpRight, Check, CheckCircle2, ChevronDown, CircleDollarSign,
  ClipboardCheck, Clock3, CreditCard, Edit3, Headphones, MoreHorizontal, Paperclip,
  RotateCcw, Send, ShieldCheck, Sparkles, WalletCards, X, Zap,
} from "lucide-react";

type Stage = "welcome" | "analyzing" | "plan" | "edit" | "executing" | "success" | "cancelled" | "error";
type Message = { id: number; role: "agent" | "user"; text: string; kind?: "normal" | "analysis" | "result" | "error" };
const initialMessages: Message[] = [{ id: 1, role: "agent", text: "你好，我是 SaveFlow。告诉我一个具体的储蓄目标，我会把它拆成可执行的消费规则。" }];
const stageCopy: Record<Stage, string> = { welcome: "等待目标", analyzing: "正在分析", plan: "等待确认", edit: "修改计划", executing: "执行中", success: "已完成", cancelled: "已取消", error: "需要处理" };

export default function Home() {
  const [stage, setStage] = useState<Stage>("welcome");
  const [messages, setMessages] = useState<Message[]>(initialMessages);
  const [input, setInput] = useState("");
  const [monthlySaving, setMonthlySaving] = useState(2500);
  const [saveRate, setSaveRate] = useState(10);
  const [demoError, setDemoError] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const progress = useMemo(() => stage === "welcome" ? 0 : stage === "analyzing" ? 28 : stage === "plan" || stage === "edit" ? 54 : stage === "executing" ? 78 : 100, [stage]);
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth", block: "end" });
  }, [messages, stage]);
  const addMessage = (message: Omit<Message, "id">) => setMessages((current) => [...current, { ...message, id: Date.now() + current.length }]);
  const startDemo = (goal = input.trim() || "我想在年底存下 2 万元") => {
    setInput(""); setDemoError(false); addMessage({ role: "user", text: goal }); setStage("analyzing");
    window.setTimeout(() => { addMessage({ role: "agent", kind: "analysis", text: "我已读取近 3 个月的模拟账单，发现固定收入稳定，但娱乐和订阅支出有优化空间。" }); setStage("plan"); }, 450);
  };
  const confirmPlan = () => {
    setStage("executing"); addMessage({ role: "user", text: "确认这个计划" });
    window.setTimeout(() => {
      if (demoError) { setStage("error"); addMessage({ role: "agent", kind: "error", text: "执行遇到异常：模拟储蓄账户可用余额不足。你可以修改金额或重新尝试。" }); return; }
      setStage("success"); addMessage({ role: "agent", kind: "result", text: "计划已生效。下次消费开始，系统会自动拆分储蓄金额。" });
    }, 650);
  };
  const editPlan = () => { setStage("edit"); addMessage({ role: "user", text: "我想调整计划" }); };
  const cancelPlan = () => { setStage("cancelled"); addMessage({ role: "user", text: "取消这次设置" }); addMessage({ role: "agent", text: "好的，本次计划没有执行。你的现有规则保持不变。" }); };
  const restart = () => { setStage("welcome"); setMessages(initialMessages); setInput(""); setDemoError(false); setMonthlySaving(2500); setSaveRate(10); };

  return <main className="app-shell">
    <aside className="sidebar"><div className="brand"><div className="brand-mark"><Sparkles size={17} /></div><span>SaveFlow</span></div><div className="workspace-label">个人财务空间</div><nav className="nav-list"><button className="nav-item active"><Headphones size={17} /> Agent 对话 <span className="nav-dot" /></button><button className="nav-item"><WalletCards size={17} /> 账户总览</button><button className="nav-item"><CreditCard size={17} /> 虚拟卡规则</button><button className="nav-item"><CircleDollarSign size={17} /> 目标储蓄</button></nav><div className="sidebar-bottom"><div className="security-note"><ShieldCheck size={16} /><span>演示环境<br /><b>数据仅保存在本地</b></span></div><button className="profile"><span className="avatar">L</span><span><b>林先生</b><small>演示用户</small></span><MoreHorizontal size={17} /></button></div></aside>
    <section className="chat-area"><header className="chat-header"><div className="agent-title"><div className="agent-avatar"><Sparkles size={16} /></div><div><b>SaveFlow Agent</b><span><i className="online" /> 在线 · 本地演示模式</span></div></div><div className="header-actions"><span className="stage-pill"><span className="stage-dot" /> {stageCopy[stage]}</span><button className="icon-button" title="重新开始演示" onClick={restart}><RotateCcw size={17} /></button><button className="icon-button" title="更多"><MoreHorizontal size={19} /></button></div></header>
      <div className="flow-strip"><div className="flow-label"><Zap size={14} /> 演示流程</div><div className="flow-track"><span className={progress >= 28 ? "done" : ""}>分析消费</span><ChevronDown size={13} /><span className={progress >= 54 ? "done" : ""}>生成计划</span><ChevronDown size={13} /><span className={progress >= 78 ? "done" : ""}>确认执行</span><ChevronDown size={13} /><span className={progress === 100 ? "done" : ""}>结果反馈</span></div><div className="progress-line"><span style={{ width: `${progress}%` }} /></div></div>
      <div className="messages"><div className="date-divider"><span>今天 09:41</span></div>{messages.map((message) => <MessageBubble key={message.id} message={message} />)}{stage === "analyzing" && <div className="typing"><span /><span /><span /> Agent 正在整理你的账单</div>}{stage === "plan" || stage === "edit" ? <PlanCard monthlySaving={monthlySaving} saveRate={saveRate} setMonthlySaving={setMonthlySaving} setSaveRate={setSaveRate} editing={stage === "edit"} onConfirm={confirmPlan} onEdit={editPlan} onCancel={cancelPlan} onSave={() => { setStage("plan"); addMessage({ role: "agent", text: "已更新计划，请确认新的储蓄安排。" }); }} /> : null}{stage === "error" && <div className="error-actions"><button className="secondary-button" onClick={() => setStage("edit")}><Edit3 size={15} /> 修改金额</button><button className="primary-button" onClick={confirmPlan}><RotateCcw size={15} /> 重试执行</button></div>}{(stage === "success" || stage === "cancelled") && <div className="restart-row"><button className="secondary-button" onClick={restart}><RotateCcw size={15} /> 重新开始演示</button></div>}<div ref={messagesEndRef} /></div>
      <div className="composer-wrap"><div className="suggestions"><button onClick={() => startDemo("我想在年底存下 2 万元")}>年底存下 2 万元</button><button onClick={() => startDemo("帮我减少娱乐消费")}>减少娱乐消费</button><button onClick={() => startDemo("找出闲置订阅")}>找出闲置订阅</button></div><div className="composer"><button className="attach"><Paperclip size={18} /></button><input value={input} onChange={(event) => setInput(event.target.value)} onKeyDown={(event) => { if (event.key === "Enter") startDemo(); }} placeholder="输入你的财务目标..." disabled={stage !== "welcome" && stage !== "success" && stage !== "cancelled"} /><button className="send" onClick={() => startDemo()} disabled={!input.trim() && stage === "welcome"}><Send size={17} /></button></div><p>SaveFlow 会在执行真实资金操作前向你确认 · 当前为模拟数据</p></div></section>
    <aside className="insights"><div className="insights-heading"><div><span className="eyebrow">LIVE OVERVIEW</span><h2>本次演示</h2></div><button className="icon-button"><MoreHorizontal size={18} /></button></div><div className="goal-card"><div className="card-top"><span>目标储蓄</span><span className="green-tag">进行中</span></div><strong>¥20,000</strong><div className="goal-progress"><span style={{ width: stage === "success" ? "38%" : "12%" }} /></div><div className="goal-foot"><span>已完成 ¥2,400</span><b>预计 12 月</b></div></div><div className="metric-grid"><div className="metric-card"><span>月收入</span><strong>¥12,000</strong><small><ArrowUpRight size={13} /> 稳定</small></div><div className="metric-card"><span>建议储蓄</span><strong>¥{monthlySaving.toLocaleString()}</strong><small><Zap size={13} /> {saveRate}% 比例</small></div></div><div className="activity-card"><div className="section-title"><span>规则预览</span><button>查看全部</button></div><RuleRow icon="餐" label="日常消费" value={`${saveRate}% 自动储蓄`} color="blue" /><RuleRow icon="娱" label="娱乐消费" value="月限额 ¥800" color="orange" /><RuleRow icon="订" label="订阅服务" value="3 项待确认" color="purple" /></div><div className="tip-card"><div className="tip-icon"><Sparkles size={16} /></div><div><b>本次演示提示</b><p>点击“修改”或“取消”，查看不同状态的结果。</p></div></div><button className="exception-toggle" onClick={() => setDemoError((value) => !value)}><AlertTriangle size={14} /> {demoError ? "已开启余额不足异常" : "开启异常路径"}<span className={demoError ? "switch on" : "switch"}><i /></span></button></aside>
  </main>;
}

function MessageBubble({ message }: { message: Message }) { return <div className={`message-row ${message.role === "user" ? "user-row" : ""}`}><div className={`message-avatar ${message.role === "user" ? "user-avatar" : ""}`}>{message.role === "user" ? "L" : <Sparkles size={14} />}</div><div className={`bubble ${message.kind || ""}`}><div className="bubble-meta">{message.role === "user" ? "你" : "SaveFlow Agent"}<span>09:4{message.id % 10}</span></div><p>{message.text}</p>{message.kind === "analysis" && <AnalysisCard />}{message.kind === "result" && <ResultCard />}{message.kind === "error" && <div className="error-banner"><AlertTriangle size={15} /> 操作未完成，资金不会被扣除</div>}</div></div>; }
function AnalysisCard() { return <div className="analysis-card"><div className="analysis-title"><div className="mini-icon blue"><ClipboardCheck size={15} /></div><div><b>消费分析完成</b><span>基于近 3 个月模拟账单</span></div><CheckCircle2 className="check" size={17} /></div><div className="analysis-stats"><div><span>月均收入</span><b>¥12,000</b></div><div><span>月均支出</span><b>¥8,640</b></div><div><span>可优化空间</span><b className="accent">¥1,180</b></div></div><div className="insight-line"><Sparkles size={14} /> 娱乐与订阅支出占比偏高，建议设置自动储蓄规则。</div></div>; }
function ResultCard() { return <div className="result-card"><div className="result-check"><Check size={18} /></div><div><b>执行成功</b><span>消费即储蓄规则已启用</span></div><div className="result-date"><Clock3 size={13} /> 刚刚</div></div>; }
function PlanCard({ monthlySaving, saveRate, setMonthlySaving, setSaveRate, editing, onConfirm, onEdit, onCancel, onSave }: { monthlySaving: number; saveRate: number; setMonthlySaving: (value: number) => void; setSaveRate: (value: number) => void; editing: boolean; onConfirm: () => void; onEdit: () => void; onCancel: () => void; onSave: () => void }) {
  return <div className={`plan-card ${editing ? "editing" : ""}`}><div className="plan-heading"><div className="mini-icon purple"><WalletCards size={16} /></div><div><b>{editing ? "调整储蓄计划" : "为你生成储蓄计划"}</b><span>{editing ? "修改后会重新计算目标完成时间" : "根据目标与现金流自动计算"}</span></div><span className="ai-badge"><Sparkles size={12} /> AI 规划</span></div><div className="plan-main"><div className="plan-number"><span>每月建议储蓄</span>{editing ? <div className="number-input"><span>¥</span><input type="number" min={0} step={100} value={monthlySaving} onChange={(e) => setMonthlySaving(Number(e.target.value))} /></div> : <strong>¥{monthlySaving.toLocaleString()}</strong>}<small>预计 8 个月完成目标</small></div><div className="plan-rule"><div className="rule-row"><span>日常消费</span>{editing ? <input className="rate-input" type="number" value={saveRate} onChange={(e) => setSaveRate(Number(e.target.value))} /> : <b>{saveRate}%</b>}<span>自动储蓄</span></div><div className="rule-row"><span>娱乐消费</span><b>12%</b><span>自动储蓄</span></div><div className="rule-row"><span>月度上限</span><b>¥3,000</b><span>保护现金流</span></div></div></div><div className="plan-note"><ShieldCheck size={14} /> 预留 ¥1,500 应急金后，仍可覆盖日常支出</div><div className="plan-actions">{editing ? <><button className="secondary-button" onClick={onCancel}><X size={15} /> 放弃修改</button><button className="primary-button" onClick={onSave}><Check size={15} /> 保存新计划</button></> : <><button className="text-button" onClick={onCancel}>取消</button><button className="secondary-button" onClick={onEdit}><Edit3 size={15} /> 修改</button><button className="primary-button" onClick={onConfirm}><Check size={15} /> 确认并执行</button></>}</div></div>;
}
function RuleRow({ icon, label, value, color }: { icon: string; label: string; value: string; color: string }) { return <div className="rule-preview-row"><span className={`rule-icon ${color}`}>{icon}</span><b>{label}</b><span>{value}</span><ChevronDown size={14} /></div>; }
